## intent:greet
- hey
- hello
- hi
- good morning
- good afternoon
- good evening
- hey there
- hi there
- Hello
- hii
- hey bot
- hello bot
- hello there

## intent:goodbye
- bye
- goodbye
- see you around
- see you later
- bye bye
- ba bye
- bye then
- ok then bye
- okay then bye
- ok bye
- okay bye
- ok goodbye
- okay goodbye
- bye, see you
- see you again
- goodbye then
- ok goodbye then

## intent:affirm
- yes
- indeed
- of course
- that sounds good
- correct
- ok
- okay
- it's fine
- this is good
- this seems to be fine
- this is nice
- done
- ok done
- okay done
- nice
- perfect
- hmm that's good
- this is perfect
- yes, done
- perfect

## intent:deny
- no
- never
- I don't think so
- don't like that
- no way
- not really
- no thanks
- nope
- no, thank you
- nothing
- no, thanks
- this is not fine
- i hate this
- i don't like it
- this is not good
- not at all
- not too good
- not good
- no it's not
- it is not fine
- not interested

##intent:specific
- can i have icecream?
- can i have ice-cream?
- can i have vanilla?
- can i have american nuts?
- can i have halwa?
- vanilla
- american nuts
- can i get pizza?
- can i get hot dog?
- can i get veg roll?
- can i get chocolate?
- cake
- pastry
- i would like to have coffee
- i would like to have coldrink
- i would like to have pizza
- i would like to have coke
- i would like to have thumps up
- i would like to have coke
- i would like to have pastry
- i would like to have cake
- i would like to have chocolate
- i would like to have pizza
- i would like to have dessert
- i would like to have kheer
- i would like to have juice
- i would like to have orange juice
- coke
- thums up
- mirinda
- limca
- pepsi
- softdrink
- i would like to have softdrink
- i would like to have pepsi
- i would like to have mirinda
- can i get juice?
- can i have juice?

##intent:desserts
- what are the desserts available?
- desserts?
- dessert
- desserts
- what is in dessert?
- do you serve dessert?
- what dessert do you serve?
- how many dessert do you serve?
- which dessert do you have?
- which dessert can i have?
- which dessert can i get?
- what can i get in dessert?
- dessert?
- i want to have some sweet
- i would like to have some sweet
- i would like to have sweet

##intent:icecreams
- can i get icecream?
- i wanna eat icecream
- i want to eat icecream
- cones?
- cone icecream
- can i get cone icecream?
- i want to eat cone icecream
- what are the available icecreams?
- show me list of icecream
- i would like to have cone icecream
- i would like to have cones
- i would like to have cone icecreams
- give me icecream
- vanilla flavour
- vanilla flavor
- strawberry flavour
- i would like to have strawberry flavour icecream
- chocolate icecream
- show me available icecream
- do you serve icecream?
- which icecream do you serve?
- i would like to have vanilla icecream
- i would like to have american nuts icecream
- i would like to have chocolate flavour icecream
- i would like to have chocolate icecream
- i would like to have faalooda icecream
- i would like to have icecream
- i would like to have vanilla
- i would like to have american nuts
- faalooda
- can i have faalooda icecream?

##intent:out_of_scope
- i want to order food
- i want to order pizza
- what is earth?
- what is food?
- what the hell is this?
- can you deliver food?
- do you have home delivery service?

##intent:menu
- show me today's menu?
- what are you serving today?
- today's menu
- i am feeling hungry
- i want to eat something
- what can i have?
- what do you serve?
- menu please
- i am hungry
- give me food
- suggest me something
- menu
- can i get menu?
- main menu
- show me main menu

##intent:breakfast
- breakfast
- breakfast menu?
- what is breakfast menu?
- what is in breakfast?
- show me breakfast menu
- show me menu of breakfast
- what can i get in breakfast?

##intent:lunch
- lunch menu
- what is in lunch?
- what is lunch menu?
- lunch menu?
- show me lunch menu
- show me menu of lunch
- what can i get in lunch?


##intent:dinner
- dinner menu
- what is in dinner?
- what is dinner menu?
- dinner menu?
- show me dinner menu
- show me menu of dinner
- what can i get in dinner?


##intent:fastfoods
- i want to eat fastfood
- can i have fastfood?
- fastfood
- fastfood menu
- fastfoods
- what is in fastfood?
- what is fastfood menu?
- show me menu of fastfood
- show me fastfood menu
- what can i get in fastfood?

##intent:inform
- [1](people)
- [2](people)
- [3](people)
- [4](people)
- [5](people)
- [6](people)
- [7](people)
- [8](people)
- [9](people)
- [10](people)
- [Rahul](name)
- [Jeevan](name)
- [Lipika](name)
- [lipika](name)
- [lipika dey](name)
- [Lipika Dey](name)
- [Romesh](name)
- [Shweta](name)
- [moderate](price)
- [cheap](price)
- [expensive](price)
- [indian](cuisine)
- [chinese](cuisine)
- [south indian](cuisine)
- [thai](cuisine)
- [veg](cuisine)
- [nonveg](cuisine)
- i am looking for a [cheap](price) restaurant
- i am looking for a nearby restaurant
- i am looking for a [moderately](price:moderate) priced restaurant
- i am looking for an [expensive](price) restaurant
- i am looking for an [indian](cuisine) restaurant
- i am looking for a [south indian](cuisine) restaurant
- i am looking for a [chinese](cuisine) restaurant
- i am looking for a [cheap](price) restaurant for [2](people) people
- i am looking for a [moderate](price) restaurant for [2](people) people
- i am looking for an [expensive](price) restaurant for [2](people) people
- we will be [4](people) people
- we will be [6](people) people
- i would prefer [cheap](price) restaurant
- i would prefer [moderate](price) restaurant
- i would prefer [expensive](price) restaurant
- search a restaurant for [6](people) nearby
- search a [cheap](price) restaurant for [6](people)
- search a [moderate](price) restaurant for [6](people)
- search an [expensive](price) restaurant for [6](people)
- i am looking for a [cheap](price) [indian](cuisine) restaurant
- i am looking for a [cheap](price) [south indian](cuisine) restaurant
- i am looking for a [moderate](price) [chinese](cuisine) restaurant
- i am looking for a [moderate](price) [indian](cuisine) restaurant
- i am looking for an [expensive](price) [indian](cuisine) restaurant
- looking for a [cheap](price) [veg](cuisine) restaurant 
- can you book a table?
- i want to book a table.
- can you make reservation?
- reserve a table
- book a table
- make a reservation
- get me a table
- can i get a table?
- can you reserve a table?
- can you reserve table?
- can you make a reservation?
- book a table for me
- can you book table?
- i am looking for a restaurant
- looking for a restaurant
- looking for a nearby restaurant


## intent:positive_feedback
- food was good
- service was good
- management was good
- staff was very polite
- best food ever
- nice location
- different cuisine were available
- within price range
- awesome
- awesome food
- great food quality
- food was very tasty
- ambience was very beautiful
- nice location
- staff was very courteous
- service was very fast
- food was awesome
- i had a nice experience
- it was a nice experience to visit there
- best cuisine
- best cuisines were available
- best location
- plates and utensils were clean
- nice experience
- food was very tasty
- yummy food
- food was yummy
- satisfactory

##intent:negative_feedback
- very crowdy place
- unhygenic
- staff was very rude
- prices were too high
- management is not good
- very ridiculous staff
- worst experience
- service is not good
- no parking area
- flower plants are not there
- food quality was not good
- need to improve
- pathetic food quality
- plates were not clean
- worst food quality
- very bad experience
- unsatisfactory
- waiters were not dress well
- too expensive
- ambience was not good
- food was not tasty
- such a creep
- worst restaurant ever
- location was not good
- tables were not clean properly
- seating arrangement was not good

##intent:thank_you
- thank you
- thanks
- thank you so much
- thanks a lot
- thanks alot
- thankyou
- Thanks
- thanks bot
- thank you bot
- thank you so much bot

## intent:bot_challenge
- are you a bot?
- are you a human?
- am I talking to a bot?
- am I talking to a human?
- who is your creator?

## intent:search_restaurant
- show me [indian](cuisine) restaurants
- show me [chinese](cuisine) restaurants
- show me [nonveg](cuisine) restaurants
- show me [veg](cuisine) restaurants
- show me [all](cuisine) restaurants 
- show me [south indian](cuisine) restaurants

## intent:reserve
- book a table in [Labela Restaurant](restaurant)
- book a table in [Restaurant Shalimar](restaurant)
- book a table in [D'EAT Family Restaurant](restaurant)
- book a table in [Dawat Restaurant](restaurant)
- book a table in [Swaruchi Restaurants](restaurant)
- book a table in [The Golden Diner](restaurant)
- make a reservation in [Labela Restaurant](restaurant)
- make a reservation in [Restaurant Shalimar](restaurant)
- make a reservation in [D'EAT Family Restaurant](restaurant)
- make a reservation in [Dawat Restaurant](restaurant)
- make a reservation in [Swaruchi Restaurants](restaurant)
- make a reservation in [The Golden Diner](restaurant)

##intent:askcuisine
- how many cuisine do you serve?
- which cuisines do you serve?
- which cuisines can i get?
- cuisines
- cuisine available

##intent:loveyoubot
- love you
- i love you
- i love you alot
- i love you very much
- i love you so much
- love you bot
- i love you bot
- i love you so much bot
- i love you very much bot
